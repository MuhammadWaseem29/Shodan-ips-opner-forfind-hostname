function createFacetButton() {
    // Create button element
    const btn = document.createElement('button');
    btn.className = 'shodan-facet-button';
    btn.textContent = 'F';
    
    // Check initial conditions
    const isFacetPage = window.location.pathname.includes('/facet');
    const totalElement = document.querySelector('.summary h4');
    const totalText = totalElement?.textContent?.replace(/,/g, '') || '';
    const totalResults = parseInt(totalText, 10);

    // Set initial state
    if (isFacetPage) {
        btn.title = 'Already in facet view';
        btn.disabled = true;
        btn.classList.add('disabled');
    } else if (!totalElement || isNaN(totalResults)) {
        btn.title = 'No valid results found';
        btn.disabled = true;
        btn.classList.add('disabled');
    } else if (totalResults > 1500) {
        btn.title = `Too many results (${totalResults})`;
        btn.disabled = true;
        btn.classList.add('disabled');
    } else {
        btn.title = `Convert ${totalResults} results to facet search`;
        btn.addEventListener('click', convertToFacet);
    }

    // Add to page
    document.body.appendChild(btn);
}

function convertToFacet() {
    try {
        const currentUrl = new URL(window.location.href);
        
        // Modify URL path
        if (!currentUrl.pathname.includes('/facet')) {
            currentUrl.pathname = currentUrl.pathname.replace('/search', '/search/facet');
        }
        
        // Add facet parameter if missing
        if (!currentUrl.searchParams.has('facet')) {
            currentUrl.searchParams.append('facet', 'ip');
        }
        
        // Remove hash if present
        currentUrl.hash = '';
        
        // Navigate to modified URL
        window.location.href = currentUrl.toString();
    } catch (error) {
        console.error('Facet conversion failed:', error);
    }
}

// Initialize when page loads
(function init() {
    // Only run on Shodan search pages
    if (!window.location.hostname.includes('shodan.io') || 
        !window.location.pathname.startsWith('/search')) {
        return;
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', createFacetButton);
    } else {
        createFacetButton();
    }
})();