document.addEventListener('DOMContentLoaded', () => {
    const convertBtn = document.getElementById('convert-btn');
    const statusDiv = document.getElementById('status');

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const activeTab = tabs[0];
        
        chrome.scripting.executeScript({
            target: { tabId: activeTab.id },
            function: analyzePage
        }, (results) => {
            if (chrome.runtime.lastError || !results?.[0]?.result) {
                updateStatus('⚠️ Not a Shodan search page', 'orange');
                convertBtn.classList.add('disabled');
                return;
            }

            const { totalResults, modifiedUrl } = results[0].result;
            
            if (totalResults === null) {
                updateStatus('❌ Total results not found', 'red');
                convertBtn.classList.add('disabled');
            } else if (totalResults > 1500) {
                updateStatus(`❌ Results (${totalResults}) exceed 1500`, 'red');
                convertBtn.classList.add('disabled');
            } else {
                updateStatus(`✅ Convertible (${totalResults} results)`, 'green');
                convertBtn.addEventListener('click', () => {
                    chrome.tabs.update(activeTab.id, { url: modifiedUrl });
                });
            }
        });
    });

    function updateStatus(text, color) {
        statusDiv.style.display = 'block';
        statusDiv.textContent = text;
        statusDiv.style.backgroundColor = color;
    }
});

function analyzePage() {
    // Get total results
    const totalElement = document.querySelector('.summary h4');
    if (!totalElement) return { totalResults: null };
    
    const totalResults = parseInt(totalElement.textContent.replace(/,/g, ''), 10);
    if (isNaN(totalResults)) return { totalResults: null };

    // Skip if already facet search
    if (window.location.pathname.includes('/facet')) {
        return { totalResults: null };
    }

    // Build modified URL
    const url = new URL(window.location.href);
    url.pathname = url.pathname.replace('/search', '/search/facet');
    
    if (!url.searchParams.has('facet')) {
        url.searchParams.append('facet', 'ip');
    }

    return {
        totalResults,
        modifiedUrl: url.toString()
    };
}