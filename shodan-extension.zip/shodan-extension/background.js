// Background script (optional for now, but kept for future use)
chrome.runtime.onInstalled.addListener(() => {
    console.log("Shodan Facet Processor extension installed.");
});