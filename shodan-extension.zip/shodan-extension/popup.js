// // Fetch URLs from the content script
// chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
//     const activeTab = tabs[0];
//     chrome.scripting.executeScript({
//         target: { tabId: activeTab.id },
//         function: processShodanResults
//     }, (results) => {
//         if (results && results[0] && results[0].result) {
//             const urls = results[0].result;
//             const textarea = document.getElementById('urls');
//             textarea.value = urls.join('\n');

//             // Add click handler for the button
//             document.getElementById('open-tabs').addEventListener('click', () => {
//                 urls.forEach(url => {
//                     chrome.tabs.create({ url });
//                 });
//             });
//         }
//     });
// });

// // Function to process Shodan results (injected into the page)
// function processShodanResults() {
//     const rows = document.querySelectorAll('.row.fresult');
//     const urls = [];

//     rows.forEach(row => {
//         const anchor = row.querySelector('a:has(strong)');
//         const countDiv = row.querySelector('.one.column.value');
        
//         if (!anchor || !countDiv) return;

//         const count = parseInt(countDiv.textContent.replace(/,/g, ''), 10);
//         let modifiedUrl = anchor.href;

//         if (count <= 1000) {
//             modifiedUrl = modifiedUrl.replace('/search?', '/search/facet?');
//             if (!modifiedUrl.includes('facet=ip')) {
//                 modifiedUrl += '&facet=ip';
//             }
//         }

//         urls.push(modifiedUrl);
//     });

//     return urls;
// }


chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const activeTab = tabs[0];
    chrome.scripting.executeScript({
        target: { tabId: activeTab.id },
        function: processShodanResults
    }, (results) => {
        if (results && results[0] && results[0].result) {
            const urls = results[0].result;
            const textarea = document.getElementById('urls');
            textarea.value = urls.join('\n');

            // Add click handler for the button
            document.getElementById('open-tabs').addEventListener('click', () => {
                urls.forEach(url => {
                    chrome.tabs.create({ url });
                });
            });
        }
    });
});

function processShodanResults() {
    const anchors = document.querySelectorAll('.facet-row .name a');
    const base = window.location.origin;
    const urls = [];

    anchors.forEach(anchor => {
        const fullUrl = base + anchor.getAttribute('href');
        urls.push(fullUrl);
    });

    return urls;
}
