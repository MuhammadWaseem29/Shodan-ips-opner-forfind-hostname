document.getElementById('downloadBtn').addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        func: () => {
          const ipElements = document.querySelectorAll('strong');
          const ips = [];
          
          ipElements.forEach(e => {
            ips.push(e.innerHTML.replace(/["']/g, ''));
          });
          
          const ipsString = ips.join('\n');
          const a = document.createElement('a');
          a.href = `data:text/plain;charset=utf-8,${encodeURIComponent(ipsString)}`;
          a.download = 'results.txt';
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
        }
      });
    });
  });