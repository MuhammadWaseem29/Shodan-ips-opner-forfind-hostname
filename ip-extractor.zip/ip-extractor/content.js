// Create and style the download button
const downloadBtn = document.createElement('button');
downloadBtn.id = 'fixedDownloadBtn';
downloadBtn.textContent = 'Download IPs';

// Apply styles
Object.assign(downloadBtn.style, {
  position: 'fixed',
  right: '20px',
  top: '50%',
  transform: 'translateY(-50%)',
  padding: '12px 24px',
  fontSize: '16px',
  backgroundColor: '#4CAF50',
  color: 'white',
  border: 'none',
  borderRadius: '8px',
  cursor: 'pointer',
  transition: 'all 0.3s',
  boxShadow: '0 4px 6px rgba(0,0,0,0.1)',
  zIndex: '9999',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  lineHeight: '1',
  textAlign: 'center',
  minWidth: '140px',
  boxSizing: 'border-box',
  fontFamily: 'Arial, sans-serif'
});

// Hover effects
downloadBtn.addEventListener('mouseover', () => {
  downloadBtn.style.backgroundColor = '#45a049';
  downloadBtn.style.transform = 'translateY(-50%) translateY(-2px)';
  downloadBtn.style.boxShadow = '0 6px 8px rgba(0,0,0,0.2)';
});

downloadBtn.addEventListener('mouseout', () => {
  downloadBtn.style.backgroundColor = '#4CAF50';
  downloadBtn.style.transform = 'translateY(-50%)';
  downloadBtn.style.boxShadow = '0 4px 6px rgba(0,0,0,0.1)';
});

// Click handler
downloadBtn.addEventListener('click', () => {
  try {
    const ips = Array.from(document.querySelectorAll('strong'))
      .map(element => element.textContent.replace(/["']/g, '').trim())
      .filter(ip => ip.length > 0);

    if (ips.length === 0) {
      alert('No IP addresses found in <strong> elements');
      return;
    }

    const blob = new Blob([ips.join('\n')], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    
    const tempLink = document.createElement('a');
    tempLink.href = url;
    tempLink.download = 'ip_addresses.txt';
    document.body.appendChild(tempLink);
    tempLink.click();
    document.body.removeChild(tempLink);
    URL.revokeObjectURL(url);

    // Send message to background script to close tab
    chrome.runtime.sendMessage({ action: "closeTab" });
    
  } catch (error) {
    console.error('Error downloading IPs:', error);
    alert('Error downloading IPs. Check console for details.');
  }
});

// Add button to the page and keep it on top
document.body.appendChild(downloadBtn);
const observer = new MutationObserver(() => {
  if (document.body.lastElementChild !== downloadBtn) {
    document.body.appendChild(downloadBtn);
  }
});
observer.observe(document.body, { childList: true });