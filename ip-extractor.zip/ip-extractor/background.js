chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "closeTab" && sender.tab) {
    setTimeout(() => {
      chrome.tabs.remove(sender.tab.id).catch(error => {
        console.log('Tab closure error:', error);
      });
    }, 10); // 10ms delay before closing
  }
  return true; // Keep message channel open
});