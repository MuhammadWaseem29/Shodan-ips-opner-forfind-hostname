import os
import re
import time

def extract_ips_from_file(file_path):
    """Extracts all IP addresses from a given file."""
    with open(file_path, 'r') as file:
        content = file.read()
    return re.findall(r'\b(?:\d{1,3}\.){3}\d{1,3}\b', content)

def append_ips_to_master(master_file_path, directory, processed_files):
    # Ensure the master file exists
    if not os.path.isfile(master_file_path):
        print("Error: Master file does not exist.")
        return

    # Collect IPs from new .txt files in the specified directory
    all_ips = set()
    for filename in os.listdir(directory):
        if filename.endswith(".txt"):
            file_path = os.path.join(directory, filename)
            if file_path not in processed_files:
                ips = extract_ips_from_file(file_path)
                all_ips.update(ips)
                processed_files.add(file_path)

    # Append unique IPs to the master file
    if all_ips:
        with open(master_file_path, 'a') as master_file:
            for ip in all_ips:
                master_file.write(ip + '\n')

        print(f"Appended {len(all_ips)} unique IPs to '{master_file_path}'.")

def monitor_directory(master_file_path, directory):
    processed_files = set()

    # Normalize directory path
    directory = os.path.normpath(directory.strip('"'))

    print("Monitoring directory for new files. Press CTRL+C to stop.")
    try:
        while True:
            append_ips_to_master(master_file_path, directory, processed_files)
            time.sleep(5)  # Check every 5 seconds
    except KeyboardInterrupt:
        print("Stopped monitoring.")

if __name__ == "__main__":
    master_file_path = input("Enter the path of the master IP file: ").strip('"')
    txt_directory = input("Enter the directory containing .txt files: ").strip('"')

    monitor_directory(master_file_path, txt_directory)